#coding: utf-8
#_-_Autor: Erlon_-_

import cv2

padraoRostos = cv2.CascadeClassifier('cascades\\haarcascade_frontalface_default.xml')

imagem = cv2.imread('pessoas\\teste4.jpg')
imagemCinza = cv2.cvtColor(imagem, cv2.COLOR_BGR2GRAY)

faceDetect = padraoRostos.detectMultiScale(imagemCinza, scaleFactor=1.2, minNeighbors=3  , minSize=(30,30))

print("Total de faces > ", len(faceDetect))
#print("Matriz da posicao das faces \n", faceDetect)
print("Matriz da posicao das faces \n|  x |  y |  l | a  |\n-------------------|")

for (x, y, l, a) in faceDetect:
	print("|",x,"|", y,"|", l,"|", a,"|",)
	cv2.rectangle(imagem, (x, y), (x+l, y+a), (255, 0, 255), 2)
	print("--------------------")

print("x > Coordenada X\ny > Coordenada Y\nl > Largura\na > Altura")

cv2.imshow("Faces encontradas", imagem)
cv2.waitKey()
