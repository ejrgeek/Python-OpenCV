#coding: utf-8
#_-_Autor: Erlon_-_

import cv2

classificadorFace = cv2.CascadeClassifier("cascades\haarcascade_frontalface_default.xml")
classificadorOlhos = cv2.CascadeClassifier("cascades\haarcascade_eye.xml")

imagem = cv2.imread("pessoas\\teste7.jpg")
imagemCinza = cv2.cvtColor(imagem, cv2.COLOR_BGR2GRAY)

facesDetectadas = classificadorFace.detectMultiScale(imagemCinza, scaleFactor=1.1, minNeighbors=9, minSize=(30,30))

print("Total de faces > ", len(facesDetectadas))
#print("Matriz da posicao das faces \n", faceDetect)
print("Matriz da posicao das faces \n|  x |  y |  l | a  |\n-------------------|")

for(x,y,l,a) in facesDetectadas:
	print("|",x,"|", y,"|", l,"|", a,"|",)
	imagem = cv2.rectangle(imagem, (x,y), (x+l, y+a), (0,0,255), 2)
	print("--------------------")
	regiao = imagem[y:y + a, x:x + l]
	regiaoCinzaOlho = cv2.cvtColor(regiao, cv2.COLOR_BGR2GRAY)
	olhosDetectados = classificadorOlhos.detectMultiScale(regiaoCinzaOlho, scaleFactor=1.05, minNeighbors=2)
	print(olhosDetectados)
	
	for (ox, oy, ol, oa) in olhosDetectados:
		cv2.rectangle(regiao, (ox, oy), (ox+ol, oy+oa), (255,0,255), 2)
	
print("x > Coordenada X\ny > Coordenada Y\nl > Largura\na > Altura")

cv2.imshow("Faces e olhos", imagem)

cv2.waitKey()
