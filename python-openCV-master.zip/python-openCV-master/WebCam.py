import cv2 # importa a biblioteca do OpenCV
import smtplib # importa a biblioteca do smtp para envio de e-mails

def enviarEmail(): # cria uma função para enviar um email
		
	server = smtplib.SMTP('smtp.gmail.com', 587) # inicia o serviço com o endereço do servidor e a porta
	server.ehlo()
	server.starttls()

	user = "" # email usado para enviar
	senha = "" # senha da conta
	para = "" #email para receber a mensagem
	msg = "UM ROSTO FOI DETECTADO" # MENSAGEM

	try: # Tenta conectar na conta
		server.login(user, senha)
		print("Logando")
		
	except: # exceção para cado falhe
		print("Email ou Senha errados || Permissao Negada")
		
	server.sendmail(user, para, msg) # passagem de parametros para o envio
	print("Email enviado")
	server.close() # fecha cnoexão com o servidor de envios

video = cv2.VideoCapture(0) #inicia a webcam
detectarFace = cv2.CascadeClassifier('cascades\\haarcascade_frontalface_default.xml') #carrega o padrão de detecção

aux = 0

while True:
	conexao, quadro = video.read() #ler ou abre uma janela para visualização do video

	quadroCinza = cv2.cvtColor(quadro, cv2.COLOR_BGR2GRAY) #converte a imagem para escala cinza, para melhor detecção
	rostoDetectado = detectarFace.detectMultiScale(quadroCinza, scaleFactor=2, minNeighbors=9, minSize=(30,30)) #passado os parametros de detecção

	for (x, y, l, a) in rostoDetectado: #laço para marcar o rosto
		cv2.rectangle(quadro, (x,y), (x + l, y + a), (0, 0, 255), 2) # posicao do retangulo
		if (x > aux):
			aux = 1000
			print("Rosto Detectado")
			enviarEmail()

	cv2.imshow("Video", quadro) #Abre uma janela com o video da webcam com o quadrado marcando as faces

	if cv2.waitKey(1) == ord('q'): #finaliza o programa se a tecla "q" for pressionada
		break

video.release() #libera captura
cv2.destroyAllWindows() #libera memoria
