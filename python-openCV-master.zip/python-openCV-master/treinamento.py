import cv2
import os
import numpy as np

eigenFace = cv2.face.EigenFaceRecognizer_create()
#eigenFace = cv2.face.EigenFaceRecognizer_create(num_components = 50, threshold = 2)
fisherFace = cv2.face.FisherFaceRecognizer_create()
#fisherFace = cv2.face.FisherFaceRecognizer_create(num_components = 50, threshold = 2)
lpbhFace = cv2.face.LBPHFaceRecognizer_create()

def imagemNomes():
	caminhos = [os.path.join('rostos', f) for f in os.listdir('rostos')]
	
	faces = []
	ids = []

	for caminhoImagem in caminhos:
		imagemFace = cv2.cvtColor(cv2.imread(caminhoImagem), cv2.COLOR_BGR2GRAY)
		identificacao = int(os.path.split(caminhoImagem)[-1].split('.')[1])
		
		ids.append(identificacao)
		faces.append(imagemFace)
	return np.array(ids), faces

ids, faces = imagemNomes()

print("Treinando")

eigenFace.train(faces, ids)
eigenFace.write('classificadorEigen.yml')

fisherFace.train(faces, ids)
fisherFace.write('classificadorFisher.yml')

lpbhFace.train(faces, ids)
lpbhFace.write('classificadorLBPH.yml')

print("Treinamento Finalizado")
