# python-openCV
Projeto de Reconhecimento e Detecção Facial usando Python e OpenCV [Palestra na Python Nordeste]
